<?php

use Illuminate\Database\Seeder;
use App\Hotel;

class HotelTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $hotel1 = [
            'title' => 'Luxurious 3 Bed Room' , 
            'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam tempor dapibus iaculis. Pellentesque vitae fringilla eros, vitae bibendum enim.',
            'advance_amount' => '30',
            'price' => '200',
            'image1' => 'hotels/images/hotel1.jpg',
            'image2' => 'hotels/images/hotel2.jpg' 
        ];

        $hotel2 = [
            'title' => 'Luxurious 2 Bed Room' , 
            'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam tempor dapibus iaculis. Pellentesque vitae fringilla eros, vitae bibendum enim.',
            'advance_amount' => '30',
            'price' => '150',
            'image1' => 'hotels/images/hotel3.jpg',
            'image2' => 'hotels/images/hotel4.jpg' 
        ];

        $hotel3 = [
            'title' => 'Luxurious Single Bed Room' , 
            'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam tempor dapibus iaculis. Pellentesque vitae fringilla eros, vitae bibendum enim.',
            'advance_amount' => '30',
            'price' => '120',
            'image1' => 'hotels/images/hotel5.jpg',
            'image2' => 'hotels/images/hotel6.jpg' 
        ];

        $hotel4 = [
            'title' => 'Standard 3 Bed Room' , 
            'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam tempor dapibus iaculis. Pellentesque vitae fringilla eros, vitae bibendum enim.',
            'advance_amount' => '30',
            'price' => '150',
            'image1' => 'hotels/images/hotel7.jpg',
            'image2' => 'hotels/images/hotel8.jpg' 
        ];

        $hotel5 = [
            'title' => 'Standard 2 Bed Room' , 
            'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam tempor dapibus iaculis. Pellentesque vitae fringilla eros, vitae bibendum enim.',
            'advance_amount' => '30',
            'price' => '120',
            'image1' => 'hotels/images/hotel9.jpg',
            'image2' => 'hotels/images/hotel10.jpg' 
        ];

        $hotel6 = [
            'title' => 'Standard Single Bed Room' , 
            'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam tempor dapibus iaculis. Pellentesque vitae fringilla eros, vitae bibendum enim.',
            'advance_amount' => '20',
            'price' => '80',
            'image1' => 'hotels/images/hotel11.jpg',
            'image2' => 'hotels/images/hotel12.jpg' 
        ];

        $hotel7 = [
            'title' => 'Onsale Single Bed Room' , 
            'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam tempor dapibus iaculis. Pellentesque vitae fringilla eros, vitae bibendum enim.',
            'advance_amount' => '20',
            'price' => '75',
            'image1' => 'hotels/images/hotel13.jpg',
            'image2' => 'hotels/images/hotel14.jpg' 
        ];

        Hotel::create($hotel1);
        Hotel::create($hotel2);
        Hotel::create($hotel3);
        Hotel::create($hotel4);
        Hotel::create($hotel5);
        Hotel::create($hotel6);
        Hotel::create($hotel7);
    }
}
