<?php $__env->startSection('content'); ?>

<section class="site-hero site-hero-innerpage overlay" data-stellar-background-ratio="0.5" style="background-image: url(<?php echo e(asset('front/images/big_image_1.jpg')); ?>);">
    <div class="container">
    <div class="row align-items-center site-hero-inner justify-content-center">
    <div class="col-md-12 text-center">
    <div class="mb-5 element-animate">
    <h1>Homtel</h1>
    <p>Discover Our Luxurious Rooms.</p>
    </div>
    </div>
    </div>
    </div>
    </section>
    
    <section class="site-section">
    <div class="container">
    <div class="row">
    <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4">
            <div class="media d-block room mb-0">
            <figure>
            <img src="<?php echo e(asset($hotel->image1)); ?>" alt="Generic placeholder image"  height="200" width="350">
            </figure>
            <div class="media-body">
            <h3 class="mt-0"><a href="<?php echo e(route('front.hotel_details',['id'=>$hotel->id])); ?>"><?php echo e($hotel->title); ?></a></h3>
            <ul class="room-specs">
            <li>Price</li>    
            <li>$<?php echo e($hotel->price); ?></li>
            </ul>
            <a href="<?php echo e(route('front.hotel_details',['id'=>$hotel->id])); ?>" class="btn btn-success btn-sm">View Details</a><br><br>
            <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($hotel->id); ?>">
                <button type="submit" class="btn btn-primary btn-sm">Book Now For $<?php echo e($hotel->advance_amount); ?> OFF</button>
            </form>
            </div>
            </div>
            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </div>
    </div>
    </section>
    <section class="section-cover" data-stellar-background-ratio="0.5" style="background-image: url(images/img_5.jpg);">
    <div class="container">
    <div class="row justify-content-center align-items-center intro">
    <div class="col-md-9 text-center element-animate">
    <h2>Relax and Enjoy your Holiday</h2>
    <p class="lead mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto quidem tempore expedita facere facilis, dolores!</p>
    <div class="btn-play-wrap"><a href="https://vimeo.com/channels/staffpicks/93951774" class="btn-play popup-vimeo "><span class="ion-ios-play"></span></a></div>
    </div>
    </div>
    </div>
    </section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front_layout.masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>