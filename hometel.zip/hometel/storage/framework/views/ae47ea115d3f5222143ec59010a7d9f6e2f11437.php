<?php $__env->startSection('content'); ?>



<?php $__env->startSection('content'); ?>

<div class="page-inner">
        <div class="page-title">
            <h3 class="breadcrumb-header">Approved Orders</h3>
        </div>
    <div id="main-wrapper">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-white">
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table id="example3" class="display table" style="width: 100%; cellspacing: 0;">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Total Advance</th>
                                        <th>Total Due</th>
                                        <th>Details</th>
                                    </tr>
                                </thead>
                                <?php
                                    $count =1;
                                ?>
                                <tfoot>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($count++); ?></td>
                                        <td><?php echo e($order->name); ?></td>
                                        <td><?php echo e($order->email); ?></td>
                                        <td><?php echo e($order->total_advance); ?></td>
                                        <td><?php echo e($order->due_amount); ?></td>
                                        <td><a href="<?php echo e(route('admin.order_details',['id'=>$order->id])); ?>" class="btn btn-success btn-sm">Details</a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                               
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- Row -->
    </div><!-- Main Wrapper -->
    <div class="page-footer">
        <p>Made with <i class="fa fa-heart"></i> by stacks</p>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout.masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin_layout.masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>