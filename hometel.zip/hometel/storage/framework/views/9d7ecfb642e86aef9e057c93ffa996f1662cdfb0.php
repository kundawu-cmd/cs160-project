<?php $__env->startSection('content'); ?>

<section class="site-hero site-hero-innerpage overlay" data-stellar-background-ratio="0.5" style="background-image: url(<?php echo e(asset('front/images/big_image_1.jpg')); ?>);">
    <div class="container">
    <div class="row align-items-center site-hero-inner justify-content-center">
    <div class="col-md-12 text-center">
    <div class="mb-5 element-animate">
    <h1>Cart</h1>
    </div>
    </div>
    </div>
    </div>
    </section>
    
    <div class="container mt-4">

            <?php if(empty($hotels)): ?>
                <div class="p-4 text-danger">
                    <p>You Have Not Booked Any Room Yet . Please Book A room</p>
                </div>
            <?php else: ?>

            <table class="table">
                    <thead class="thead-dark">
                      <tr>
                        <th scope="col">Room Title</th>
                        <th scope="col">Price</th>
                        <th scope="col">Advance Amount</th>
                        <th scope="col">Due Amount</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody style="color:#991f00">
                        <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($hotel['title']); ?></td>
                            <td><?php echo e($hotel['price']); ?></td>
                            <td><?php echo e($hotel['advance_amount']); ?></td>
                            <td><?php echo e($hotel['due_price']); ?></td>
                            <td>
                                <form action="<?php echo e(route('cart.remove')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($key); ?>">
                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Remove</button>
                                </form>
                            </td>
                        </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td>Total Advance</td>
                            <td><?php echo e($total); ?> </td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                  </table>
                  
                  
                <a href="<?php echo e(route('cart.clear')); ?>" class="btn btn-danger btn-sm">Clear Cart</a>
                <a href="<?php echo e(route('checkout')); ?>" class="btn btn-success btn-sm">Checkout</a>
            <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front_layout.masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>